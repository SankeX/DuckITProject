function search() {
	alert ("Search is disbaled at the current time");
}
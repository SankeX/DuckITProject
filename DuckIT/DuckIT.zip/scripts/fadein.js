 $(document).ready(function () {
	  $("body").css({ display: 'none'}).fadeIn(3200);;
    });
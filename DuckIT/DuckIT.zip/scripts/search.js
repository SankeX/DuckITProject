function search() {
	alert ("Search is disbaled at the current time");
}
function social(type) {
	alert ("Sorry, this link to "+type+" is disabled.")
}
